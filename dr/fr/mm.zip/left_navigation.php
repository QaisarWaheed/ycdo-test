<nav>
	<ul id="nav_1">
<?php if($is_admin == 2){ ?>
		<!--<li>-->
		<!--	<a target="_blank" href="patient_registeration.php">Patient Registeration</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="patient_registeration_complete.php">Patient Registeration(COMPLETE)</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="second_turn.php">Second Turn</a>-->
		<!--</li>		-->
		<!--<li>-->
		<!--	<a target="_blank" href="second_turn_pending.php">Second Turn(Pending)</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="donation_collection.php">Donation Collection</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="branch_procedure_pendings.php">Procedure Turn</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="item_receive_branch.php">Receive Item In Branch</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="show_branch_stock_deemand.php">Show Branch Stock Deemand</a>-->
		<!--</li>-->
<?php }	?>
		<li>
			<a style="cursor: pointer;" href='dashboard.php' class="">Dashboard</a>
		</li>
		<li>
			<a style="cursor: pointer;" href='user_summary.php' class="">Summary</a>
		</li>
		<li>
			<a style="cursor: pointer;" href='user_summary_login.php' class="">Summary Login Wise</a>
		</li>
		<li>
			<a style="cursor: pointer;" href='progress_report.php' class="">Progress Report</a>
		</li>
		<li>
			<a style="cursor: pointer;" href='user_complete_summary.php' class="">Complete Summary</a>
		</li>
		<li>
			<a href="logout.php">Logout</a>
		</li>
	</ul>
</nav>

<?php
date_default_timezone_set("Asia/Karachi");
$current_date = date('Y-m-d h:i:s A');
error_reporting(1);
session_start();
if (isset($_SESSION['bk_id'])) {
    $bk_id = $_SESSION['bk_id'];
    $bk_name = $_SESSION['bk_name'];
    $bk_branch_id = $_SESSION['branch_id'];
    $bk_is_admin = $_SESSION['is_admin'];;
    $bk_is_incharge = $_SESSION['is_incharge'];
    $bk_branch_name = $_SESSION['branch_name'];
    $bk_branch_address = $_SESSION['branch_address'];
    $bk_branch_phone = $_SESSION['branch_phone'];
}
else
{
//    header('location: logout.php'); 
}
include 'company_info.php'; 
$con = mysqli_connect('localhost', 'ycdoeh1', 'ycdoeh1', 'ycdomlt');
if(!$con)
{
    echo $con->error;
}
function get_uname_by_id($id)
{
    $output = '';
    $run = mysqli_query($GLOBALS['con'], "SELECT u_name FROM `users` WHERE `id` = '$id' ");
    if (mysqli_num_rows($run) == 1) 
    {
        while ($row = mysqli_fetch_array($run)) 
        {
            $output .= $row['u_name'];
        }    
    }    
    return $output;
}

?>
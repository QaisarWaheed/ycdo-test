<nav>
	<ul id="nav_1">
		<li>
			<a style="cursor: pointer;" href='dashboard.php' class="">Dashboard</a>
		</li>

<?php if($bk_is_admin == 1 && $bk_is_incharge == 1){ ?>
		<li>
			<a style="cursor: pointer;" href='user_summary.php' class="">Summary</a>
		</li>
		<li>
			<a style="cursor: pointer;" href='user_summary_login.php' class="">Summary Login Wise</a>
		</li>
<?php }	?>
		<li>
			<a href="logout.php">Logout</a>
		</li>
	</ul>
</nav>

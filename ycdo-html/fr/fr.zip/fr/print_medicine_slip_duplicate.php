<?php include 'includes/connect.php'; ?>
<?php include 'includes/head.php'; ?>
	<title>Dashboard - <?php echo $company_trademark; ?></title>
<script>
* {
    font-size: 12px;
    font-family: 'Times New Roman';
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
}
    
</script>
</head>
<body>
<?php
if (isset($_POST['tokan_no']) && $_POST['tokan_no'] != '') {
	$token_id = $_POST['tokan_no'];
}
elseif (isset($_GET['tokan_no']) && $_GET['tokan_no'] != '') {
	$token_id = $_GET['tokan_no'];
}
$select = "SELECT `tokan_type_id` FROM `tokans` WHERE `id` = '$token_id' ";
$run = mysqli_query($con, $select);
if (mysqli_num_rows($run) > 0) 
{
	while ($row = mysqli_fetch_array($run)) 
	{
		$tokan_type_id = $row['tokan_type_id'];
		if ($tokan_type_id > 100) 
		{
			echo print_medicine_slip_duplicate($token_id); 
		}
		else
		{
			echo print_tokan_duplicate($token_id); 
		}
	}
}

?>

</body>
</html>
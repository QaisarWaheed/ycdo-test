<?php 
include 'includes/connect.php'; 
include 'includes/head.php'; 

if (isset($_GET['add_token']) && $_GET['enter_token'] != '' && $_GET['add_token']) 
{
	$token_no = $_GET['enter_token'];
	$select = "SELECT * FROM tokans WHERE id = '$token_no' AND `tokan_type_id` < 100 ";
	$run = mysqli_query($con, $select);
	if (mysqli_num_rows($run) == 1) 
	{
		while ($row = mysqli_fetch_array($run)) 
		{
			$patient_id = $row['patient_id'];
            $select_patient = "SELECT * FROM patients WHERE id = '$patient_id' ";
            $run_patient = mysqli_query($con, $select_patient);
            if (mysqli_num_rows($run_patient) == 1) 
            {
                while ($row_patient = mysqli_fetch_array($run_patient)) 
                {
                	$phone = $row_patient['phone'];
                	if ($phone == NULL) 
                	{
                		$error = "NOT VALID TOKEN NO";
                	}
                	else
                	{
                		header('location: second_procedure_turn.php?search_tokan_no='.$token_no);
                	}
                }
            }
		}
	}
	else
	{
	$error = "ENTER A VALID TOKEN NO";
	}
}
?>
	<title>Branch Procedure Pendings - <?php echo $company_trademark; ?></title>
</head>

<body class="background_image_ycdo">

<div>

	<div class="" style="margin: 10px 15px;">

	<div class="row">

		<table class="table">
			<thead>
				<caption style="caption-side: top;text-align: center;">
					<h3>BRANCHS PROCEDURE</h3>
				</caption>
				<?php
				if (isset($error)) {
					echo '<tr><td colspan="14">'.$error.'</td></tr>';
				 } 
				?>
				<tr>
					<th colspan="10">
						<form method="GET">
							<input type="number" name="enter_token" />
							<input type="submit" name="add_token" class="btn btn-sm btn-primary" />
						</form>
					</th>
					<th colspan="4">
						<form method="GET">
<?php 
$select_b = "SELECT * FROM `branchs` WHERE id = '$branch_id' ";
$run_b = mysqli_query($con, $select_b);
if (mysqli_num_rows($run_b) == 1) {
	while ($row_b = mysqli_fetch_array($run_b)) {
		echo '<input readonly input="text" class="form-control" value="'.$row_b['address'].'"/>';
	}
}
?>
						</form>
					</th>
				</tr>
				<tr>
					<th>S #</th>
					<th>Token Date</th>
					<th>Patient Name</th>
					<th>Gardian Name</th>
					<th>Token No</th>
					<th>Token Type</th>
					<th>Procedure Name</th>
					<th>Total Amount</th>
					<th>Received Amount</th>
					<th>Pending Amount</th>
					<th>Pending Recomended BY</th>
					<th>Give Medicines</th>
					<th>Pending Recievings</th>
					<th>Update</th>
				</tr>
			</thead>
			<tbody>
<?php
$s = 0;
$select_branch_pending_query = "SELECT * FROM `branch_pending_details` WHERE status = '1' ";
$select_branch_pending = mysqli_query($con, $select_branch_pending_query);
if (mysqli_num_rows($select_branch_pending) > 0) 
{
	while ($row_branch_data = mysqli_fetch_array($select_branch_pending) ) 
	{
		$s = $s + 1;
		$amount = 0;
		$branch_pending_id = $row_branch_data['id'];
		$gardian_name = $row_branch_data['gardian_name'];
		$gardian_phone = $row_branch_data['gardian_phone'];
		$recommended_by = $row_branch_data['recommended_by'];
		$token_no = $row_branch_data['token_no'];
		$select_token = mysqli_query($con, "SELECT * FROM `tokans` WHERE id = '$token_no' ");
		if (mysqli_num_rows($select_token) > 0) 
		{
			while ($row_token = mysqli_fetch_array($select_token)) 
			{
				$token_no = $row_token['id'];
                    $run2 = mysqli_query($GLOBALS['con'], "SELECT * FROM `branch_pending_receive` WHERE token_no = '$token_no' AND status = '1' ");
                    if (mysqli_num_rows($run2) > 0) 
                    {
                        while ($row = mysqli_fetch_array($run2)) 
                        {
                            $amount = $amount - $row['amount'];
                        }
                    }
				$procedure_name = get_procedure_name($token_no);
				$token_type_title = token_type_title($row_token['tokan_type_id']);
				$patient_name = get_patient_name_by_id($row_token['patient_id']);
				$total_amount = $row_token['cash'];
				$recieved_amount = $row_token['cash_received'];
				$created = $row_token['created'];
			}
		}

    $pending_amount = intval($total_amount-($recieved_amount-$amount));
echo '
<tr>
	<td>'.$s.'</td>
	<td>'.date_format(date_create($created), "d-m-Y").'</td>
	<td>'.$patient_name.'</td>
	<td>'.$gardian_name.'</td>
	<td><a class="btn btn-sm btn-outline-info" href="branch_pending_complete_detail.php?token_no='.$token_no.'"">'.$token_no.'</a></td>
	<td>'.$token_type_title.'</td>
	<td>'.$procedure_name.'</td>
	<td>'.$total_amount.'</td>
	<td>'.$recieved_amount.'</td>
	<td>'.$pending_amount.'</td>
	<td>'.$recommended_by.'</td>
	<td>
		<a class="btn btn-sm btn-outline-primary" href="second_procedure_turn_medicines.php?search_tokan_no='.$token_no.'">Medicines</a>
	</td>';
	if($pending_amount > 0)
	{
	echo '<td>
		<a class="btn btn-sm btn-outline-info" href="procedure_pending_amount.php?search_tokan_no='.$token_no.'">Pay Amount</a>
	</td>';
	}
	else
	{
	echo '<td>
		<a class="btn btn-sm btn-success" >CLEAR</a>
	</td>';
	}
	if ($branch_pending_id != 0) {
	echo '<td><a href="branch_pending_detail_update.php?u_id='.$branch_pending_id.'">Update</a></td>';
	}
	else
		echo '<td></td>';	
echo '</tr>
';

	}
}
?>
			</tbody>
		</table>

	</div>
</div>

</div>

</body>
</html>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<!-- 
 -->
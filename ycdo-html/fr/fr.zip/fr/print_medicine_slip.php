<?php include 'includes/connect.php'; ?>
<?php include 'includes/head.php'; ?>
	<title>Dashboard - <?php echo $company_trademark; ?></title>
</head>

<body>
<?php
if (isset($_POST['tokan_no']) && $_POST['tokan_no'] != '') {
	$tokan_id = $_POST['tokan_no'];
	echo print_medicine_slip($tokan_id); 
}
if (isset($_GET['tokan_no']) && $_GET['tokan_no'] != '') {
	$tokan_id = $_GET['tokan_no'];
	echo print_medicine_slip($tokan_id); 
}

?>

</body>
</html>
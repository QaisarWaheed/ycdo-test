<!DOCTYPE html>
<html>
<?php 
session_start();
    $user_name = $_SESSION['ph_name'];
$con = mysqli_connect('localhost', 'ycdo', 'YCDO!@#', 'ycdo');
if(isset($_GET['s']) && $_GET['s'])
{
    $date = $_GET['s'];
    $b_id = $_GET['b_id'];
}
else
{
    exit();
}
?>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

<table border="1" style="margin: auto auto;">
    <caption style="caption-side: top;">
        <h2>YCDO EXECUTIVE HOSPITAL 2</h2>
        <h3>DAILY PROGESS REPORT MOTHER & CHILD CARE</h3>
        <h3>DATE: <span><?php echo date_format(date_create($date), 'd-m-Y'); ?></span></h3>
    </caption>
    <thead>
        <tr>
            <th>Sr</th>
            <th>DR NAME</th>
            <th>DUTY TIME</th>
            <th>OPD</th>
            <th>D/P</th>
            <th>D/T</th>
            <th>AMOUNT</th>
            <th>USG</th>
            <th>SVD DNC</th>
            <th>PROCEDURE</th>
            <th>ADMISSION</th>
        </tr>
    </thead>
    <tbody>
<?php
$total_opd = 0;
$total_pd = 0;
$total_test = 0;
$total_test_amount = 0;
$total_usg = 0;
$total_svd = 0;
$total_procedure = 0;
$total_addmission = 0;
$dr_count = 0;
// $select_dr = "SELECT * FROM users WHERE id IN (SELECT doctor_id FROM tokans WHERE created LIKE '$date%') ";
$select_dr = "SELECT * FROM users WHERE ( role_id = 3 OR id IN (SELECT doctor_id FROM tokans WHERE created LIKE '$date%') ) AND status = '1' ORDER BY u_name";
$run_dr = mysqli_query($con, $select_dr);
if(mysqli_num_rows($run_dr) > 0)
{
    while($row_dr = mysqli_fetch_array($run_dr))
    {
        $dr_id = $row_dr['id'];
        $count_opd = mysqli_num_rows(mysqli_query($con, "SELECT id FROM tokans WHERE doctor_id = '$dr_id' AND created LIKE '$date%' AND tokan_type_id < '100' AND status = '1' "));
        $total_opd = $total_opd + $count_opd;
        $count_pd = mysqli_num_rows(mysqli_query($con, "SELECT id FROM tokans WHERE doctor_id = '$dr_id' AND created LIKE '$date%' AND tokan_type_id > '99' AND status = '1' "));
        $total_pd = $total_pd + $count_pd;
        $count_test = mysqli_num_rows(mysqli_query($con, "SELECT id FROM tokans WHERE doctor_id = '$dr_id' AND created LIKE '$date%' AND tokan_type_id > '99' AND id IN (SELECT tokan_no FROM `item_by_doctor` WHERE `item_id` IN (SELECT id FROM item_register_to_branches WHERE item_id IN (SELECT id FROM items WHERE category_id = 2)))"));
        $total_test = $total_test + $count_test;
        $count_usg = mysqli_num_rows(mysqli_query($con, "SELECT id FROM tokans WHERE doctor_id = '$dr_id' AND created LIKE '$date%' AND tokan_type_id > '99' AND id IN (SELECT tokan_no FROM `item_by_doctor` WHERE `item_id` IN (SELECT id FROM item_register_to_branches WHERE item_id IN (431, 432, 433, 550)))"));
        $total_usg = $total_usg + $count_usg;
        $count_svd = mysqli_num_rows(mysqli_query($con, "SELECT id FROM tokans WHERE doctor_id = '$dr_id' AND created LIKE '$date%' AND tokan_type_id > '99' AND id IN (SELECT tokan_no FROM `item_by_doctor` WHERE `item_id` IN (SELECT id FROM item_register_to_branches WHERE item_id IN (425)))"));
        $total_svd = $total_svd + $count_svd;
        $count_procedure = mysqli_num_rows(mysqli_query($con, "SELECT id FROM tokans WHERE doctor_id = '$dr_id' AND created LIKE '$date%' AND tokan_type_id > '99' AND id IN (SELECT tokan_no FROM `item_by_doctor` WHERE `item_id` IN (SELECT id FROM item_register_to_branches WHERE item_id IN (SELECT id FROM items WHERE category_id = 3)))"));
        $total_procedure = $total_procedure + $count_procedure;
        $count_addmission = mysqli_num_rows(mysqli_query($con, "SELECT id FROM tokans WHERE doctor_id = '$dr_id' AND created LIKE '$date%' AND tokan_type_id > '99' AND id IN (SELECT tokan_no FROM `item_by_doctor` WHERE `item_id` IN (SELECT id FROM item_register_to_branches WHERE item_id IN (521, 532, 536, 539, 540, 528, 529, 590)))"));
        $total_addmission = $total_addmission + $count_addmission;
    $lab_amount = 0;
    $lab = "SELECT * FROM `item_by_doctor` WHERE tokan_no IN (SELECT id FROM tokans WHERE doctor_id = '$dr_id' AND created LIKE '$date%' AND tokan_type_id > '99') AND `item_id` IN (SELECT id FROM item_register_to_branches WHERE item_id IN (SELECT id FROM items WHERE category_id = 2)) AND `created` LIKE '$date%' ";
    $run_lab = mysqli_query($con, $lab);
    if(mysqli_num_rows($run_lab) > 0)
    {
        while($row_lab = mysqli_fetch_array($run_lab))
        {
            $branch_item_id = $row_lab['item_id'];
            $tn = $row_lab['tokan_no'];
            $select_tn = "SELECT `tokan_type_id` FROM `tokans` WHERE `id` = '$tn' ";
            $run_tn = mysqli_query($con, $select_tn);
            if(mysqli_num_rows($run_tn) > 0)
            {
                while($row_tn = mysqli_fetch_array($run_tn))
                {
                    $title_id = $row_tn['0'];
                    $select_i = "SELECT `general` FROM `items` WHERE `id` IN (SELECT item_id FROM item_register_to_branches WHERE id = '$branch_item_id') ";
                    $run_i = mysqli_query($con, $select_i);
                    if(mysqli_num_rows($run_i) > 0)
                    {
                        while($row_i = mysqli_fetch_array($run_i))
                        {
                            $test_amount = $row_i['0'];
                        }
                    }                    
                }
            }
            $fix_dose = $row_lab['fix_dose'];
            if ($fix_dose == 0) 
            {
                $quantity = $row_lab['dose'] * $row_lab['feed'] * $row_lab['days'];
            }
            else
            {
                $quantity = $fix_dose;
            }
            $lab_amount = $lab_amount + ($quantity * $test_amount);
        }
	}
        $dr_count = $dr_count + 1;
        $dr_name = $row_dr['u_name'];
        $total_test_amount = $total_test_amount + $lab_amount;
        echo '
        <tr>
            <td>'.$dr_count.'</td>
            <td>'.$dr_name.'</td>
            <td>00:00 AM</td>
            <td>'.$count_opd.'</td>
            <td>'.$count_pd.'</td>
            <td>'.$count_test.'</td>
            <td>'.$lab_amount.'</td>
            <td>'.$count_usg.'</td>
            <td>'.$count_svd.'</td>
            <td>'.$count_procedure.'</td>
            <td>'.$count_addmission.'</td>
        </tr>
        ';
    }
}
?>      
<tr>
    <th colspan="3" style="text-align: right;">TOTAL</th>
    <th><?php echo $total_opd; ?></th>
    <th><?php echo $total_pd; ?></th>
    <th><?php echo $total_test; ?></th>
    <th><?php echo $total_test_amount; ?></th>
    <th><?php echo $total_usg; ?></th>
    <th><?php echo $total_svd; ?></th>
    <th><?php echo $total_procedure; ?></th>
    <th><?php echo $total_addmission; ?></th>
</tr>
    </tbody>
<tr>
    <td colspan="11">&nbsp; </td>
</tr>

<tr>
    <td colspan="2" style="text-align: right;">LAB TOTAL</td>
    <td colspan="9"><?php echo $total_test_amount; ?></td>
</tr>
<?php
$compute = 0;
$received = 0;
$select = "SELECT * FROM `tokans` WHERE `status` = '1' AND `created` LIKE '$date%' ";
$run = mysqli_query($con, $select);
if(mysqli_num_rows($run) > 0)
{
    while($row = mysqli_fetch_array($run))
    {
        $computer = $computer + $row['cash'];
        $received = $received + $row['cash_received'];
    }
}
?>
<tr>
    <td colspan="2" style="text-align: right;">Computer TOTAL CASH</td>
    <td  colspan="9"><?php echo $computer; ?></td>
</tr>
<tr>
    <td  colspan="2" style="text-align: right;">TOTAL RECEIVED CASH</td>
    <td  colspan="9"><?php echo $received; ?></td>
</tr>    
    <tr>
        <td colspan="11">PREPARED BY: <span><?php echo $user_name; ?></span></td>
    </tr>
</table>

</body>
</html>
<?php include 'includes/connect.php'; ?>
<?php include 'includes/head.php'; ?>
	<title>Logout - <?php echo $company_trademark; ?></title>
</head>

<body>

<div class="container">
<form method="POST">
	<div class="row">
		<div class="col-md-12">
			<label>ENTER PHYSICALL AMOUNT</label>
			<input type="number" min="1" name="physicall_cash" class="form-control"> 
		</div>
		<div class="col-md-12" style="margin-top: 30px;">
			<input type="submit" value="SUBMIT PHYSICALL CASH" name="physicall_cash" class="form-control btn btn-outline-primary"> 
		</div>
	</div>
</form>	
</div>

<?php 
if (isset($_POST['physicall_cash'])) 
	{ ?>
<table class="table">
	<tr>
		<th>S No</th>
		<td>1</td>
		<th>Branch</th>
		<td><?php echo $branch_address; ?></td>
	</tr>
	<tr>
		<th>Name</th>
		<td><?php echo $user_name; ?></td>
		<th>Login Time</th>
		<td><?php $start_date = login_time($user_id); echo date_format(date_create($start_date),'d-M-Y h:i:s A'); ?></td>
	</tr>
	<tr>
		<th>Login As</th>
		<td><?php echo show_role_by_user_id($user_id); ?></td>
		<th>Logout Time</th>
		<td><?php echo date('d-M-Y h:i:s A'); ?></td>
	</tr>
	<tr>
		<th colspan="2" style="text-align: right;">Computer Cash(Tokens)</th>
		<td colspan="2"><?php echo number_format($cash = get_total_token_cash($user_id, $start_date, date('Y-m-d h:i:s'))); ?></td>
	</tr>
	<tr>
		<th colspan="2" style="text-align: right;">Cash Received(Tokens)</th>
		<td colspan="2"><?php echo  number_format( $cash_received = get_total_token_cash_received($user_id, $start_date, date('Y-m-d h:i:s'))); ?></td>
	</tr>
	<tr>
		<th colspan="2" style="text-align: right;">Other Cash(Extra cash)</th>
		<td colspan="2"><?php echo number_format($cash_received-$cash); ?></td>
	</tr>
	<tr>
		<th colspan="2" style="text-align: right;">Donation Collection</th>
		<td colspan="2"><?php echo number_format($donation_amount = get_total_donation_collection($user_id, $start_date, date('Y-m-d h:i:s'))); ?></td>
	</tr>
	<tr>
		<th colspan="2" style="text-align: right;">Total Cash</th>
		<td colspan="2"><?php echo number_format($cash_received + $donation_amount); ?></td>
	</tr>
	<tr>
		<th colspan="2" style="text-align: right;">Total Cash Received</th>
		<td colspan="2"><?php echo show_role_by_user_id($user_id); ?></td>
	</tr>
</table>
<?php } ?>
</body>
</html>
<?php include 'includes/connect.php'; 
if (isset($_POST['save'])) {
	$tokan_no = next_tokan_no();
	$id = $_POST['registeration_no'];
	$name = $_POST['name'];
	$last_name = $_POST['last_name'];
	$cnic = $_POST['cnic'];
	$phone = $_POST['phone'];
	$age = $_POST['age'];
	$address = $_POST['address'];
	$gender = $_POST['gender'];
	$ref_name = $_POST['ref_name'];
	$ref_phone = $_POST['ref_phone'];
	$tokan_type = $_POST['tokan_type'];
	$cash = $_POST['cash'];
	$run = mysqli_query($con, "INSERT INTO `patients`
	(`id`, `name`, `last_name`, `cnic`, `phone`, `age`, `address`, `gender`, `ref_name`, `ref_phone`, `created`) 
	VALUES 
	('$id', '$name', '$last_name', '$cnic', '$phone', '$age', '$address', '$gender', '$ref_name', '$ref_phone', '$current_date')");

	$run4 = mysqli_query($con, "INSERT INTO `tokans`
	(`id`, `patient_id`, `doctor_id`, `tokan_type_id`, `cash`, `cash_received`, `user_id`, `created`) 
	VALUES 
	('$tokan_no', '$id','0', '$tokan_type', '$cash', '$cash', '$user_id', '$current_date')");	
	if (!$run4) 
	{
		echo 'ERROR: '.$con->error;
	}
	else
	{
?>
<script type="text/javascript">
	alert("Success: Data save successfullly");
	window.open("print_tokan.php?tokan_no=<?php echo $tokan_no; ?>", "_blank", "toolbar=no,scrollbars=no,resizable=no,top=500,left=500,width=400,height=400,status=no");
</script>
<?php		
	}
}
?>
<?php include 'includes/head.php'; ?>
	<title>Patient Complete Registeration - <?php echo $company_trademark; ?></title>
    <script type="text/javascript" src="js/jquery-3.6.0.min.js"></script> 
</head>

<body class="background_image_ycdo">

<div>

<div class="container" style="">

	<div class="row">

			<div class="col-md-12" style="text-align: center;">
				<label><h1>Patient Registeration (COMPLETE)</h1></label>
			</div>		

				<form method = "POST">

					<div class="row">

						<div class="col-md-4">
							<label>Patient Registeration #</label>
							<input type="text" value="<?php echo next_patient_id(); ?>" name="registeration_no" readonly class="form-control">
						</div>
						<div class="col-md-4">
							<label>Patient Registeration Date</label>
							<input type="date" readonly value="<?php echo date('Y-m-d'); ?>" name="registeration_date" class="form-control">
						</div>

						<div class="col-md-4">
							<label>Patient CNIC</label>
							<input pattern="[0-9]{13}" type="text" name="cnic" class="form-control" required>
						</div>
						<div class="col-md-4">
							<label>Patient Name</label>
							<input pattern="[a-z A-Z].{2,}" type="text" name="name" class="form-control" required>
						</div>
						<div class="col-md-4">
							<label>Patient Father</label>
							<input pattern="[a-z A-Z].{2,}" type="text" name="last_name" class="form-control" required>
						</div>

						<div class="col-md-4">
							<label>Patient Phone</label>
							<input pattern="[0-9]{11}" type="text" name="phone" required class="form-control">
						</div>

						<div class="col-md-4">
							<label>Patient Gender</label>
							<select name="gender" required class="form-control">
								<option value="">Select Gender</option>
								<option value="1">Female</option>
								<option value="2">Male</option>
								<option value="3">Other</option>
							</select>
						</div>

						<div class="col-md-4">
							<label>Patient Age</label>
							<input type="text" required name="age" class="form-control">
						</div>

						<div class="col-md-4">
							<label>Patient Address</label>
							<input type="text" required name="address" class="form-control">
						</div>

						<div class="col-md-4">
							<label>Patient Ref Name</label>
							<input type="text" pattern="[a-z A-Z].{2,}" name="ref_name" class="form-control" required>
						</div>

						<div class="col-md-4">
							<label>Patient Ref Phone</label>
							<input type="text" pattern="[0-9]{11}" name="ref_phone" class="form-control" required>
						</div>
						<div class="col-md-4">
							<label>Cash Received</label>
							<textarea name="cash" class="form-control" rows="1" style="resize: none;" readonly id="cash">250</textarea>
						</div>

	<!--					<div class="col-md-4">-->
	<!--						<label for="tokan_type">Token Type</label>-->
	<!--						<select size="3" id="tokan_type" name="tokan_type" required class="form-control">-->
	<!--								<option selected onclick="myFunction2()" value="2"> GERENAL</option>-->
	<!--								<option onclick="myFunction9()" value="9"> MEMBER</option>-->
	<!--								<option onclick="myFunction5()" value="5"> CONSULTANT - General</option>-->
	<!--								<option onclick="myFunction6()" value="6"> CONSULTANT - Member</option>-->
 <!--<option onclick="myFunction8()" value="8"> DESERVING</option> -->
 <!--<option onclick="myFunction5()" value="5"> CONT - G</option> -->
	<!--						</select>-->
	<!--					</div>-->
						<div class="col-md-12" id="detail">
							
						</div>
							<div class="row">
								<!--<div class="col-md-1">-->
								<!--	<input onclick="myFunction1()"  id="poor" type="radio" name="tokan_type" value="1">-->
								<!--</div>-->
								<!--<div class="col-md-2">-->
								<!--	<label for="poor" style="cursor: pointer;">Poor</label>-->
								<!--</div>-->
								<div class="col-md-1">
									<input onclick="myFunction2()" checked id="general" type="radio" name="tokan_type" value="2">
								</div>
								<div class="col-md-2">
									<label for="general" style="cursor: pointer;">general</label>
								</div>
								<div class="col-md-1">
									<input onclick="myFunction3()" id="member" type="radio" name="tokan_type" value="3">
								</div>
								<div class="col-md-2">
									<label for="member" style="cursor: pointer;">Member</label>
								</div>
								<div class="col-md-1">
									<input onclick="myFunction4()" id="urgent" type="radio" name="tokan_type" value="4">
								</div>
								<div class="col-md-2">
									<label for="urgent" style="cursor: pointer;">Emergency</label>
								</div>
							</div>
							<div class="row">
								<div class="col-md-1">
									<input onclick="myFunction5()" id="consultant3" type="radio" name="tokan_type" value="5">
								</div>
								<div class="col-md-5">
									<label for="consultant3" style="cursor: pointer;">Consultant-General</label>
								</div>
								<div class="col-md-1">
									<input onclick="myFunction6()" id="consultant2" type="radio" name="tokan_type" value="6">
								</div>
								<div class="col-md-5">
									<label for="consultant2" style="cursor: pointer;">Consultant-Member</label>
								</div>
								<!--<div class="col-md-1">-->
								<!--	<input onclick="myFunction7()" id="consultant1" type="radio" name="tokan_type" value="7">-->
								<!--</div>-->
								<!--<div class="col-md-3">-->
								<!--	<label for="consultant1" style="cursor: pointer;">Cons.-P</label>-->
								<!--</div>-->
							</div>
						<div class="col-md-12" style="margin: 20px 0px;">

							<input type="submit" name="save" value="SAVE TOKEN" class="btn btn-success">

							<input type="reset" name="clear" value="CLEAR FORM" class="btn btn-warning">

							<a href="patient_registeration.php" class="btn btn-primary">PATIENT REGISTERATION</a>
						</div>

					</div>

				</form>

	</div>
	
</div>

</div>

</body>
</html>
<script>
function myFunction2() 
{
  document.getElementById("cash").innerHTML = 250;
}
function myFunction4() 
{
  document.getElementById("cash").innerHTML = 300;
}
function myFunction9() 
{
  document.getElementById("cash").innerHTML = 200;
}
function myFunction5() 
{
  document.getElementById("cash").innerHTML = 700;
}
function myFunction6() 
{
  document.getElementById("cash").innerHTML = 500;
}
function myFunction3() 
{
  document.getElementById("cash").innerHTML = 200;
}
</script>

<?php include 'includes/connect.php'; 
if (isset($_POST['save'])) {
	$tokan_no = next_tokan_no();
	$patient_id = $_POST['registeration_no'];
	$name = $_POST['name'];
	$age = $_POST['age'];
	$patient_reg_date = $_POST['registeration_date'];
	$cash = $_POST['cash'];
	$tokan_type = $_POST['tokan_type'];
	$doctor_id = $_POST['doctor_id'];
	$gender = $_POST['gender'];
	$run = mysqli_query($con, "INSERT INTO `patients`
	(`id`, `name` ,`age` , `gender`, `created`) 
	VALUES 
	('$patient_id','$name','$age','$gender', '$current_date')");

	$run2 = mysqli_query($con, "INSERT INTO `tokans`
	(`id`, `patient_id`, `doctor_id`, `tokan_type_id`, `cash`, `cash_received`, `user_id`, `created`) 
	VALUES 
	('$tokan_no', '$patient_id','$doctor_id', '$tokan_type', '$cash', '$cash', '$user_id', '$current_date')");
?>
<script>
  window.open("print_tokan.php?tokan_no=<?php echo $tokan_no; ?>", "_blank", "toolbar=no,scrollbars=no,resizable=no,top=500,left=500,width=400,height=400,status=no");
</script>
<?php
}
?>
<?php include 'includes/head.php'; ?>
	<title>Patient Registeration - <?php echo $company_trademark; ?></title>
</head>

<body class="background_image_ycdo" onkeydown="return (event.keyCode != 116)">

<div>

	<div class="" style="margin: 10px 15px;">

		<div class="row">

			<div class="col-md-12" style="text-align: center;">
				<label><h1>Patient Registeration Form</h1></label>
			</div>
			<div class="col-md-12">

				<form method = "POST">

					<div class="row">

						<div class="col-md-4">
							<label>Patient Registeration #</label>
							<input type="text" value="<?php echo next_patient_id(); ?>" name="registeration_no" readonly class="form-control">
						</div>
						<div class="col-md-4">
							<label>Patient Registeration Date</label>
							<input type="date" readonly value="<?php echo date('Y-m-d'); ?>" name="registeration_date" class="form-control">
						</div>

						<div class="col-md-4">
							<label>Patient Name</label>
							<input pattern="[a-z A-Z].{2,}" type="text" name="name" class="form-control" required>
						</div>
						<div class="col-md-4">
							<label>Patient Age</label>
							<input type="number" name="age" class="form-control" required>
						</div>


						<div class="col-md-4">
							<label>Patient Gender</label>
							<select name="gender" required class="form-control">
								<option value="">Select Gender</option>
								<option value="1">Female</option>
								<option value="2">Male</option>
								<option value="3">Other</option>
							</select>
						</div>				
						<div class="col-md-4">
							<label>DOCTOR</label>
					<select name="doctor_id" required class="form-control">
						<option value="">Select doctor</option>
						
<?php
$get_doctor = mysqli_query($con, "SELECT * FROM users WHERE role_id = '3' AND branch_id = '$branch_id' ");
if (mysqli_num_rows($get_doctor) > 0) 
{
while ($row_doctor = mysqli_fetch_array($get_doctor)) 
{
  echo '<option value="'.$row_doctor['id'].'">'.$row_doctor['u_name'].'</option>';
}
}
?>
					</select>
						</div>

						<div class="col-md-8">
							<fieldset>
								<legend>
									<label><strong>OPD. Checkup Type</strong></label>
								</legend>
							
							<div class="row">
								<!--<div class="col-md-1">-->
								<!--	<input onclick="myFunction1()"  id="poor" type="radio" name="tokan_type" value="1">-->
								<!--</div>-->
								<!--<div class="col-md-2">-->
								<!--	<label for="poor" style="cursor: pointer;">Poor</label>-->
								<!--</div>-->
								<div class="col-md-1">
									<input onclick="myFunction2()" checked id="general" type="radio" name="tokan_type" value="2">
								</div>
								<div class="col-md-2">
									<label for="general" style="cursor: pointer;">general</label>
								</div>
								<div class="col-md-1">
									<input onclick="myFunction3()" id="member" type="radio" name="tokan_type" value="3">
								</div>
								<div class="col-md-2">
									<label for="member" style="cursor: pointer;">Member</label>
								</div>
								<div class="col-md-1">
									<input onclick="myFunction4()" id="urgent" type="radio" name="tokan_type" value="4">
								</div>
								<div class="col-md-2">
									<label for="urgent" style="cursor: pointer;">Emergency</label>
								</div>
							</div>
							<div class="row">
								<div class="col-md-1">
									<input onclick="myFunction5()" id="consultant3" type="radio" name="tokan_type" value="5">
								</div>
								<div class="col-md-5">
									<label for="consultant3" style="cursor: pointer;">Consultant-General</label>
								</div>
								<div class="col-md-1">
									<input onclick="myFunction6()" id="consultant2" type="radio" name="tokan_type" value="6">
								</div>
								<div class="col-md-5">
									<label for="consultant2" style="cursor: pointer;">Consultant-Member</label>
								</div>
								<!--<div class="col-md-1">-->
								<!--	<input onclick="myFunction7()" id="consultant1" type="radio" name="tokan_type" value="7">-->
								<!--</div>-->
								<!--<div class="col-md-3">-->
								<!--	<label for="consultant1" style="cursor: pointer;">Cons.-P</label>-->
								<!--</div>-->
							</div>
							</fieldset>
						</div>
						<div class="col-md-4">
							<label>Cash Received</label>
							<textarea name="cash" class="form-control" rows="1" style="resize: none;" readonly id="cash">250</textarea>
						</div>
						<div class="col-md-12" style="margin: 20px 0px;">

							<input type="submit" name="save" value="SAVE TOKEN" class="btn btn-success">
							<input type="reset" name="clear" value="CLEAR FORM" class="btn btn-warning">
<!-- 							<a href="patient_card_registeration.php" class="btn btn-primary">PATIENT CARD</a> -->
							<!--<a onclick="window.open('patient_tokan_duplicate.php','_blank','width=400,height=260')" class="btn btn-info">DUPLICATE</a>-->

						</div>

					</div>

				</form>
			</div>

		</div>

	</div>

</div>


</body>
</html>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script>
// function myFunction1() 
// {
//   document.getElementById("cash").innerHTML = 10;
// }
function myFunction2() 
{
  document.getElementById("cash").innerHTML = 250;
}
function myFunction3() 
{
  document.getElementById("cash").innerHTML = 200;
}
function myFunction4() 
{
  document.getElementById("cash").innerHTML = 300;
}
function myFunction7() 
{
  document.getElementById("cash").innerHTML = 100;
}
function myFunction6() 
{
  document.getElementById("cash").innerHTML = 500;
}
function myFunction5() 
{
  document.getElementById("cash").innerHTML = 700;
}
</script>
<script type = "text/javascript" >  
    function preventBack() { window.history.forward(); }  
    setTimeout("preventBack()", 0);  
    window.onunload = function () { null };  
</script> 
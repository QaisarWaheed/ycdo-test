<?php include 'includes/connect.php'; ?>
<?php include 'includes/head.php'; ?>
	<title>Dashboard - <?php echo $company_trademark; ?></title>
<script>
* {
    font-size: 12px;
    font-family: 'Times New Roman';
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
}
    
</script>
</head>

<body onload="window.print()">
<?php
if (isset($_POST['tokan_no']) && $_POST['tokan_no'] != '') {
	$tokan_id = $_POST['tokan_no'];
	echo print_tokan($tokan_id); 
}
if (isset($_GET['tokan_no']) && $_GET['tokan_no'] != '') {
	$tokan_id = $_GET['tokan_no'];
	echo print_tokan($tokan_id); 
}

?>

</body>
</html>
<script type="text/javascript">
        window.onfocus = function () { window.close();}
</script>
<?php include 'includes/connect.php'; 

if (isset($_GET['save']) && $_GET['save'] != '') 
{
	$tokan_no = next_tokan_no();
	if (isset($_GET['previous_tokan_no'])) 
	{
		$previous_tokan_no = $_GET['previous_tokan_no'];
		$patient_id = $_GET['patient_id'];
		$doctor_id = $_GET['doctor_id'];
		$tokan_type = $_GET['tokan_payment'];
		$cash = $_GET['cash'];
		$cash_received = $_GET['cash_received'];
		$insert = "INSERT INTO `tokans`
		(`id`, `patient_id`, `doctor_id`, `tokan_type_id`, `cash`,`cash_received`, `user_id`, `previous_tokan_no`, `created`) 
		VALUES 
		('$tokan_no', '$patient_id','$doctor_id', '$tokan_type', '$cash', '$cash_received', '$user_id', '$previous_tokan_no', '$current_date')";
	}
	else
	{
		$patient_id = next_patient_id();
		$name = $_GET['name'];
		$age = $_GET['age'];
		$gender = $_GET['gender'];
		$tokan_type = $_GET['tokan_payment'];
		$cash = $_GET['cash'];
		$cash_received = $_GET['cash_received'];
		$doctor_id = $_GET['doctor_id'];
			$run2 = mysqli_query($con, "INSERT INTO `patients`
			(`id`, `name` ,`age` , `gender`, `created`) 
			VALUES 
			('$patient_id','$name','$age','$gender', '$current_date')");

		$insert = "INSERT INTO `tokans`
		(`id`, `patient_id`, `doctor_id`, `tokan_type_id`, `cash`,`cash_received`, `user_id`, `previous_tokan_no`, `created`) 
		VALUES 
		('$tokan_no', '$patient_id','$doctor_id', '$tokan_type', '$cash', '$cash_received', '$user_id', NULL, '$current_date')";

	}
			if (mysqli_query($con, $insert)) 
			{
				if ($cash > $cash_received) 
				{
				    $ref_name = $_GET['ref_name'];
				    $ref_phone = $_GET['ref_phone'];
				    $recommended_by = $_GET['recommended_by'];
				    $return_date = $_GET['return_date'];
				    $pending_amount = $cash - $cash_received;
					mysqli_query($con, "INSERT INTO `branch_daily_pending_details`
					(`token_no`,  `ref_name`, `ref_phone`, `recommended_by`, `amount`, `return_date`, `created`) 
					VALUES 
					('$tokan_no', '$ref_name', '$ref_phone', '$recommended_by', '$pending_amount', '$return_date', '$current_date')");
				}
				mysqli_query($con, "
					UPDATE `item_by_doctor` SET 
					tokan_no = '$tokan_no', 
					status = '2', 
					doctor_id = '$doctor_id'
					WHERE branch_id = '$branch_id' AND user_id = '$user_id' AND tokan_no IS NULL
					");
				mysqli_query($con, "
					UPDATE `tests_by_doctor` SET 
					token_no = '$tokan_no', 
					status = '2'
					WHERE user_id = '$user_id' AND token_no IS NULL
					");
				$select_test = "SELECT * FROM `item_by_doctor` WHERE tokan_no = '$tokan_no' AND `item_id` IN (SELECT id FROM items WHERE category_id = '2') ";
				$run_test = mysqli_query($con, $select_test);
				if (mysqli_num_rows($run_test) > 0) {
					while ($row_test = mysqli_fetch_array($run_test)) {
						$item_id = $row_test['item_id'];
						mysqli_query($con, "INSERT INTO `tests_by_doctor`
							(`token_no`, `test_id` `user_id`, `created`) VALUES
							('$tokan_no', '$item_id', '$current_date')");
					}
				}
			}

?>
<script>
  window.open("print_medicine_slip.php?tokan_no=<?php echo $tokan_no; ?>", "_blank", "toolbar=no,scrollbars=no,resizable=no,top=500,left=500,width=400,height=400,status=no");
  location.replace("second_turn.php");
</script>
<?php
}

if (isset($_GET['del_medicine']) && $_GET['del_medicine'] != '') 
{
	$del_id = $_GET['del_medicine'];
	$delete_test = "DELETE FROM `tests_by_doctor` WHERE `user_id` = '$user_id' AND `test_id` IN (SELECT item_id FROM item_by_doctor WHERE id = '$del_id');";
		mysqli_query($con, $delete_test);
	$delete = "DELETE FROM item_by_doctor WHERE id = '$del_id' AND user_id = '$user_id' AND branch_id = '$branch_id' AND `tokan_no` IS NULL ";
	$delete_branch_data = "DELETE FROM `item_register_to_branches` WHERE id = '$del_id' AND user_id = '$user_id' AND branch_id = '$branch_id' AND `tokan_no` IS NULL ";
		$reg_item_id = get_branch_item_id_from_select_by_doctor_id($del_id);
		$quantity = get_item_quantity_from_item_by_docotr_by_id($del_id);
		$get_available_quantity = get_register_item_quantity_from_item_id($reg_item_id);
		$new_quantity = $get_available_quantity + $quantity;
		$update = "UPDATE `item_register_to_branches` SET `quantity`= '$new_quantity' WHERE id = '$reg_item_id' ";
	if (mysqli_query($con, $delete)) 
	{
		mysqli_query($con, $update);

		echo '<script type="text/javascript">
		alert("Data Deleted Successfully...");
  location.replace("second_turn.php");
		</script>';
	}
}

if (isset($_GET['save_test'])) 
{
	$reg_item_id = $_GET['reg_item_id'];
	$fix_dose = $_GET['fix_dose'];
	$dose = $_GET['dose'];
	$feed = $_GET['feed'];
	$days = $_GET['days'];
	if ($fix_dose == 0) 
	{
	$quantity = $dose * $days * $feed;
	}
	else
	{
			$quantity = $fix_dose;
	}
	$check_item = mysqli_num_rows(mysqli_query($con, "SELECT * FROM `item_by_doctor` WHERE item_id = '$reg_item_id' AND user_id = '$user_id' AND status = '1' "));
	$check_test = mysqli_num_rows(mysqli_query($con, "SELECT id FROM `items` WHERE category_id = '2' AND `id` IN (SELECT item_id FROM `item_register_to_branches` WHERE id = '$reg_item_id') "));
	$insert = "INSERT INTO `item_by_doctor`
	(`item_id`,      `dose`,  `feed`,  `days`,  `user_id`,  `branch_id`, `fix_dose`, `created`) VALUES 
	('$reg_item_id', '$dose', '$feed', '$days', '$user_id','$branch_id', '$fix_dose', '$current_date')";
	if($check_item == 0)
	{	
		$get_available_quantity = get_register_item_quantity_from_item_id($reg_item_id);
		$new_quantity = $get_available_quantity - $quantity;
		mysqli_query($con, "UPDATE `item_register_to_branches` SET `quantity`= '$new_quantity' WHERE id = '$reg_item_id' ");
		if (mysqli_query($con, $insert))		{ 
			if ($check_test == 1) {
				mysqli_query($con, "INSERT INTO `tests_by_doctor`(`test_id`, `user_id`, `created`) VALUES('$reg_item_id', '$user_id', '$current_date')");
			}
			?>
	<script type="text/javascript">
			  location.replace("second_turn.php");
			</script>
	<?php	}
	}
	else
	{ ?>
	<script type="text/javascript">
		alert("INFO: Data already addad");
	  location.replace("second_turn.php");	
	</script>
<?php }
}
include 'includes/head.php'; ?>
	<title>SECOND TURN - <?php echo $company_trademark; ?></title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous" />
</head>

<body class="background_image_ycdo" onkeydown="return (event.keyCode != 116)">

<div>

	<div class="container">
		
		<div class="row">

			<div class="col-md-12" style="text-align: center;">
				<label><h1>Patient Medicine</h1></label>
			</div>
<div class="col-md-12">
	<form name="search" method="get">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-4 btn btn-outline-primary">
				<label>NEXT TOKEN NO:<?php echo next_tokan_no().' / '.date('y'); ?></label>
			</div>
		<div class="col-md-4">
			<input formaction="search" type="number" placeholder="Token" name="search_tokan_no" max="<?php echo intval(next_tokan_no())-1; ?>" required min="1" class="form-control">
		</div>	
		<div class="col-md-2">
			<input type="submit" name="" value="SEARCH">
			<input type="submit" name="duplicate" value="DUPLICATE">
		</div>
		<div>
			
		</div>
		</div>			
	</form>
</div>
	<div class="col-md-12">			
<form>
	
<div class="row">
<div class="col-md-12">
	<fieldset class="border p-2">
	<legend style="font-size: 14px;" class="w-auto">SELECT TEST OR MEDICINE OR PROCEDURE</legend>
	<div class="row">

	<div class="col-md-6">
		<select required name="reg_item_id" id="select_item" placeholder="Pick Test, Medicine Or Procedure" class="form-control">
			<option value="">Select Test, Medicine, Procedure...</option>
		    <?php echo branch_medicines_by_name(); ?>
		</select>

  <label>DOSE:</label>

  <input type="radio" checked name="dose" value="1" id="od">
  <label for="od" title="ONCE A DOSE">OD</label>

  <input type="radio" name="dose" value="2" id="bd">
  <label for="bd" title="TWO DOSES">BD</label>

  <input type="radio" name="dose" value="3" id="tds">
  <label for="tds" title="THREE DOSES">TDS</label>

<br>
<div class="row">
	<div class="col-md-12">
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Feed:</label>
    <div class="col-sm-10">
		<select class="form-control" name="feed" required>
			<option value="0.5">Half</option>
			<option selected value="1">One</option>
			<option value="2">Two</option>
			<option value="3">Three</option>
			<option value="4">Four</option>
			<option value="5">Five</option>
			<option value="6">Six</option>
			<option value="7">Seven</option>
			<option value="8">Eight</option>
			<option value="9">Nine</option>
			<option value="10">Ten</option>
		</select>
    </div>
  </div>  
  <div class="form-group row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Days:</label>
    <div class="col-sm-4">
		<input class="form-control" type="number" name="days" value="1" min="1">
    </div>
    <label for="fix_dose" class="col-sm-3 col-form-label">Fix / Not:</label>
    <div class="col-sm-3">
		<input class="form-control" id="fix_dose" type="number" name="fix_dose" value="0" min="0">
    </div>
  </div>		
	</div>
</div>
<div class="col-md-12" style="text-align: right;" >
	<input type="submit" name="save_test" value="ADD" class="btn btn-sm btn-primary">
	<input type="submit" name="clear" value="CLEAR" class="btn btn-sm btn-warning">
</div>


   	</div>
   	<div class="col-md-6">
   		<select id="mySelect" ondblclick="del_medicine();" class="form-control" size="8">
   			<?php echo medicine_selected(); ?>
   		</select>
   	</div>

   </div>
</fieldset>

</div>

</div>

</form>

<form onsubmit="return checknumber(this);">
<div class="row">
<?php
if ( isset($_GET['duplicate']) && isset($_GET['search_tokan_no']) && $_GET['search_tokan_no'] != '') {
		$tokan_id = $_GET['search_tokan_no'];
//	echo print_medicine_slip($tokan_id); 

echo '<script>
  window.open("print_medicine_slip_duplicate.php?tokan_no='.$tokan_id.'", "_blank", "toolbar=no,scrollbars=no,resizable=no,top=500,left=500,width=400,height=400,status=no");
  location.replace("second_turn.php");
</script>';

}
elseif (isset($_GET['search_tokan_no']) && $_GET['search_tokan_no'] != '') 
{ 
	$tokan_no = $_GET['search_tokan_no'];
	$select_tokan = "SELECT * FROM tokans WHERE id = '$tokan_no' ";
	$run_tokan = mysqli_query($con, $select_tokan);
	if (mysqli_num_rows($run_tokan) == 1) 
	{
		while ($row_tokan = mysqli_fetch_array($run_tokan)) 
		{
			$doctor_id = $row_tokan['doctor_id'];
			$patient_id = $row_tokan['patient_id'];
			$select_patient = "SELECT * FROM patients WHERE id = '$patient_id' ";
			$run_patient = mysqli_query($con, $select_patient);
			if (mysqli_num_rows($run_patient) == 1) 
			{
				while ($row_patient = mysqli_fetch_array($run_patient)) 
				{
					$name = $row_patient['name'];
					$age = $row_patient['age'];
					$cnic = $row_patient['cnic'];
					$gender = $row_patient['gender'];
				}
			}

		}
	}
	?>
	<div class="col-md-3">
		<label>Patient Name</label>
		<input type="hidden" name="patient_id" value="<?php echo $patient_id; ?>">
		<input type="hidden" name="previous_tokan_no" value="<?php echo $tokan_no; ?>">
		<input readonly type="text" class="form-control" value="<?php echo $name; ?>">
	</div>
	<div class="col-md-2">
		<label>Patient CNIC</label>
		<input required readonly  type="text" name="cnic" class="form-control" value="<?php echo $cnic; ?>">
	</div>
	<div class="col-md-3">
		<label> Refference Name</label>
		<input required type="text" name="ref_name" class="form-control">
	</div>
	<div class="col-md-2">
		<label> Refference Phone</label>
		<input required type="text" name="ref_phone" class="form-control">
	</div>
	<div class="col-md-2">
		<label>Recommended By</label>
		<input required type="text" name="recommended_by" class="form-control">
	</div>
	<div class="col-md-3">
		<label>Return Date</label>
		<input required type="date" name="return_date" class="form-control">
	</div>

	<div class="col-md-2">
		<label> Age</label>
		<input readonly type="number" value="<?php echo $age; ?>" min="0" class="form-control">
	</div>
	<div class="col-md-2">
		<label> Gender</label>
		<select readonly required class="form-control">
<?php 
if ($gender == 1) {echo '<option value="1"> Female</option>';}
elseif ($gender == 2) {echo '<option value="2"> Male</option>';}
else {echo '<option value="3"> Other</option>';}
?>
		</select>
	</div>
	<div class="col-md-3">
		<label>Checked By</label>
		<select name="doctor_id" required class="form-control">
		<?php 	$get_doctor = mysqli_query($con, "SELECT * FROM users WHERE role_id = '3' AND branch_id = '$branch_id' ");
		if (mysqli_num_rows($get_doctor) > 0) 
		{	
			while ($row_doctor = mysqli_fetch_array($get_doctor)) 
		    {
		    	$option_doctor_id = $row_doctor['id'];
		    	if ($doctor_id == $option_doctor_id) 
		    	{
		      echo '<option selected value="'.$row_doctor['id'].'">'.$row_doctor['u_name'].'</option>';
		    	}
		    	else
		    	{
		      echo '<option value="'.$row_doctor['id'].'">'.$row_doctor['u_name'].'</option>';
		    	}

		    }
		} ?>
		</select>
	</div>
   	<div class="col-md-2">
   		<label>Cash</label>

   		<textarea readonly required rows="1" style="resize: none;" readonly id="cash" name="cash" class="form-control">0</textarea>
   	</div>
<?php }
else
{ ?>

	<div class="col-md-3">
		<label>Patient Name</label>
		<input required readonly type="text" name="name" class="form-control">
	</div>
	<div class="col-md-2">
		<label>Patient CNIC</label>
		<input required readonly  type="text" name="cnic" class="form-control">
	</div>
	<div class="col-md-3">
		<label>Refference Name</label>
		<input required readonly type="text" name="ref_name" class="form-control">
	</div>
	<div class="col-md-2">
		<label>Refference Phone</label>
		<input required readonly type="text" name="ref_phone" class="form-control">
	</div>
	<div class="col-md-2">
		<label>Recommended By</label>
		<input required readonly type="text" name="recommended_by" class="form-control">
	</div>
	<div class="col-md-3">
		<label>Return Date</label>
		<input required readonly type="date" name="return_date" class="form-control">
	</div>
	<div class="col-md-2">
		<label> Age</label>
		<input required readonly type="number" min="0" name="age" class="form-control">
	</div>
	<div class="col-md-2">
		<label> Gender</label>
		<select name="gender" required readonly class="form-control">
			<option value=""> Gender</option>
			<option value="1">Female</option>
			<option value="2">Male</option>
			<option value="3">Other</option>
		</select>
	</div>
	<div class="col-md-3">
		<label>Checked By</label>
		<select name="doctor_id" required class="form-control">
			<option value="">Select doctor</option>			
		<?php 	
		$b_id = $_SESSION['branch_id'];
		$dr = "SELECT * FROM users WHERE role_id = '3' AND branch_id = '$b_id' ";
		$get_doctor = mysqli_query($con, $dr);
		if (mysqli_num_rows($get_doctor) > 0) 
		{	
			while ($row_doctor = mysqli_fetch_array($get_doctor)) 
		    {
		      echo '<option value="'.$row_doctor['id'].'">'.$row_doctor['u_name'].'</option>';
		    }
		}
		else
		    {
		      echo '<option value="">'.$dr.'</option>';
		    }
?>
		</select>
	</div>
   	<div class="col-md-2">
   		<label>Cash</label>

   		<textarea readonly required rows="1" style="resize: none;" readonly id="cash" name="cash" class="form-control">0</textarea>
   	</div>
<?php } ?>


   	<div class="col-md-7" style="font-size: 15px;">
   		<label>Amonut Tokan Type</label><br>

   		<input disabled="disabled" onclick="myFunction101()" type="radio" id="deserving"  name="tokan_payment" value="101">
   		<label for="deserving">Deserving</label>
   		
   		<input onclick="myFunction102()" type="radio" id="poor" required name="tokan_payment" value="102">
   		<label for="poor">Poor</label>
   		
   		<input onclick="myFunction103()" type="radio" id="member"  name="tokan_payment" value="103">
   		<label for="member">YCDO / Member</label>
   		
   		<input onclick="myFunction104()" type="radio" id="general"  name="tokan_payment" value="104">
   		<label for="general">General</label>
   		
   	</div>


   	<div class="col-md-3">
   		<label>Cash Received</label>
   		<input type="number" name="cash_received" class="form-control" required>
   	</div>

	<div class="col-md-2">
		<br>
		<input type="submit" value="SAVE" name="save" class="btn btn-sm btn-primary">
		<input type="reset" value="CLEAR" name="clear" class="btn btn-sm btn-warning">
	</div>

</div>

</form>

</div>

		</div>
	</div>
</div>

</body>

</html>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript">
      $(document).ready(function () {
  $('#select_item').selectize({
      sortField: 'text'
  });
  $(".alert").alert();
});
</script>
<script type="text/javascript">
function del_medicine() 
{
	var x = document.getElementById("mySelect").value;
	window.open('second_turn.php?del_medicine='+x,'_self');
}	
</script>

<script>
function myFunction101() {
	//DESERVING
  document.getElementById("cash").innerHTML = <?php echo get_amount(101); ?>;
  // document.getElementById("tokan_get1").innerHTML = 8;
}
function myFunction102() {
	//POOR
  document.getElementById("cash").innerHTML = <?php echo get_amount(102); ?>;
  // document.getElementById("tokan_get1").innerHTML = 9;
}
function myFunction103() {
	//MEMBER
  document.getElementById("cash").innerHTML = <?php echo get_amount(103); ?>;
  // document.getElementById("tokan_get1").innerHTML = 1;
}
function myFunction104() {
	//GENERAL
  document.getElementById("cash").innerHTML = <?php echo get_amount(104); ?>;
  // document.getElementById("tokan_get1").innerHTML = 2;
}
</script>

<script type = "text/javascript" >  
    function preventBack() { window.history.forward(); }  
    setTimeout("preventBack()", 0);  
    window.onunload = function () { null };  
</script> 

<script type = "text/javascript" >
	function checknumber(theForm) {   
 if (parseInt(theForm.cash.value) == 0 ) 
    { 
    alert('Please add Medicines');
            return false;
     } 
     return true;
            
}
</script> 
<nav>
	<ul id="nav_1">
		<!--<li>-->
		<!--	<a target="_blank" href="patient_registeration.php">Patient Registeration</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="patient_registeration_complete.php">Patient Registeration(COMPLETE)</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="second_turn.php">Second Turn</a>-->
		<!--</li>		-->
		<!--<li>-->
		<!--	<a target="_blank" href="second_turn_pending.php">Second Turn(Pending)</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="donation_collection.php">Donation Collection</a>-->
		<!--</li>-->
<?php if($is_admin == 2){ ?>
		<!--<li>-->
		<!--	<a target="_blank" href="branch_procedure_pendings.php">Procedure Turn</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="item_receive_branch.php">Receive Item In Branch</a>-->
		<!--</li>-->
		<!--<li>-->
		<!--	<a target="_blank" href="show_branch_stock_deemand.php">Show Branch Stock Deemand</a>-->
		<!--</li>-->
<?php }	?>
		<li>
			<a style="cursor: pointer;" href='dashboard.php' class="">Dashboard</a>
		</li>
		<li>
			<a style="cursor: pointer;" href='user_summary.php' class="">Summary</a>
		</li>
		<li>
			<a style="cursor: pointer;" href='user_summary_login.php' class="">Summary Login Wise</a>
		</li>
		<li>
			<a style="cursor: pointer;" href='progress_report.php' class="">Progress Report</a>
		</li>
		<li>
			<a href="email.php">EMAIL</a>
		</li>
		<li>
			<a href="logout.php">Logout</a>
		</li>
		<!--<li>-->
		<!--	<a href="logout_with_report.php">Logout (Report)</a>-->
		<!--</li>-->
	</ul>
</nav>

<!-- 		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('second_turn.php','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=850,height=550,left=160,top=80')">Second Turn</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Second Turn(Days)</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Third Turn</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Doctor Checkup</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Lab Test</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Room</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Membership Form</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Donor Form</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Pharmacy</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Labortory</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('#','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Branch Form</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('index3.php','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Member Collection</a>
		</li>
		<li>
			<a style="cursor: pointer;" 
			onclick="window.open('datalist.php','targetWindow','directories=no,titlebar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no,width=400,height=400,left=400,top=100')">Donation Collection</a>
		</li>
		<li><a href="print_tokan.php">TOKAN</a></li>
 -->